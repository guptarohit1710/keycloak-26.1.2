import{cO as o}from"./main-oXeeBmgR.js";const s=t=>r=>r&&o(t,r)||"—";export{s as t};
//# sourceMappingURL=translationFormatter-DoqWkL9t.js.map
