import{jsx as a}from"react/jsx-runtime";import{a as r,Z as n}from"./main-oXeeBmgR.js";const l=t=>{const{t:o}=r();return a(n,{...t,labelOn:o("on"),labelOff:o("off")})};export{l as D};
//# sourceMappingURL=SwitchControl-BuBL-LwA.js.map
