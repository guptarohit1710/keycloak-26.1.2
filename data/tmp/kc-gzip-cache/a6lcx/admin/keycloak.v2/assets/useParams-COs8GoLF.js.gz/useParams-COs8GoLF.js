import{c as s}from"./main-oXeeBmgR.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-COs8GoLF.js.map
